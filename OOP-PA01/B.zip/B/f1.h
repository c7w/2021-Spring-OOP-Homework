// f1.h
#if !defined(__F1_H__)
#define __F1_H__
#if defined(__F1__)
extern int f1(int a, int b);
#endif /*__F1__*/
#endif /*__F1_H__*/