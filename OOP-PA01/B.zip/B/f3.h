// f3.h
#if !defined(__F3_H__)
#define __F3_H__
#if defined(__F3__)
extern int f3(int a, int b);
#endif /*__F3__*/
#endif /*__F3_H__*/