#include "f3.h"
int f3(int a, int b)
{
	return a + (b * 2021) + 3;
}

