// f4.h
#if !defined(__F4_H__)
#define __F4_H__
#if defined(__F4__)
extern int f4(int a, int b);
#endif /*__F4__*/
#endif /*__F4_H__*/