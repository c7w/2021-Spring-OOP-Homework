#include "node.h"

void PlaceholderNode::set_val(float val){
    this->value_ = val;
}

void PlaceholderNode::calc(){

}

Node::~Node(){}